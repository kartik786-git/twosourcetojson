﻿using LinqToExcel;
using Newtonsoft.Json;
using readexcel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            // read data from excel file
            string pathToExcelFile = AppDomain.CurrentDomain.BaseDirectory + @"\input1.xlsx";
            ConnexionExcel ConxObject = new ConnexionExcel(pathToExcelFile);
            var query1 = (from a in ConxObject.UrlConnexion.Worksheet<ExcelSource>() select new { a.EAN, a.Name }).ToList();


            // read data from csv file
            string pathToCSVFile = AppDomain.CurrentDomain.BaseDirectory + @"\input2.csv";
            ConnexionExcel CSVConxObject = new ConnexionExcel(pathToCSVFile);
            var query2 = (from a in CSVConxObject.UrlConnexion.Worksheet<CSVSource>() select new { a.EAN , a.CdnUrl , a.LastUpdated }).ToList();

            var q = (from pd in query1
                     join od in query2 on pd.EAN equals od.EAN
                     orderby od.LastUpdated descending
                     select new
                     {
                         pd.EAN,
                         pd.Name,
                         od.CdnUrl,
                     }).GroupBy(g => g.EAN).Select(x => x.FirstOrDefault()); ;

            
            var json = JsonConvert.SerializeObject(q);
            Console.WriteLine(json);
            Console.ReadLine();
        }
    }
}
