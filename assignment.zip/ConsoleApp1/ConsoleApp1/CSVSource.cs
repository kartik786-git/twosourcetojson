﻿using LinqToExcel.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace readexcel
{
    public class CSVSource
    {

        [ExcelColumn("UniqueIdentifier1")]
        public int EAN { get; set; }

        public string CdnUrl { get; set; }

        public DateTime LastUpdated { get; set; }
    }
}
